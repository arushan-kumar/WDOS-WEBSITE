document.addEventListener('DOMContentLoaded', () => {
    const itemPrices = {
        'apple': 3,
        'banana': 2,
        'orange': 4,
        'grape': 5,
        'pear': 4.5,
        'kiwi': 6,
        'carrot': 1,
        'broccoli': 2,
        'spinach': 3,
        'potato': 0.5,
        'onion': 1.5,
        'pepper': 2.5,
        'milk': 1.5,
        'cheese': 25,  // $5/200g -> $25/kg
        'butter': 20,  // $4/200g -> $20/kg
        'yogurt': 4,   // $2/500g -> $4/kg
        'cream': 12,   // $3/250g -> $12/kg
        'icecream': 12, // $6/500g -> $12/kg
        'chicken': 8,
        'beef': 10,
        'salmon': 12,
        'shrimp': 15,
        'fish': 10,
        'pork': 18,
        'flour': 2,
        'sugar': 1.5,
        'salt': 0.5,
        'baking_powder': 30, // $3/100g -> $30/kg
        'vanilla': 100,  // $5/50ml -> $100/L
        'olive_oil': 8
    };

    document.querySelectorAll('section button').forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const section = e.target.closest('section');
            const select = section.querySelector('select');
            const quantityInput = section.querySelector('input[type="number"]');
            const selectedItem = select.options[select.selectedIndex];
            const itemName = selectedItem.value;
            const itemText = selectedItem.text;
            const quantity = parseFloat(quantityInput.value);

            if (quantity > 0) {
                addItemToTable(itemText, quantity, itemPrices[itemName] * quantity);
                updateTotalPrice();
            }

            quantityInput.value = '';
        });
    });

    function addItemToTable(name, quantity, price) {
        const tableBody = document.querySelector('#items-table tbody');
        const row = document.createElement('tr');

        const nameCell = document.createElement('td');
        nameCell.textContent = name;

        const quantityCell = document.createElement('td');
        quantityCell.textContent = `${quantity} kg`;

        const priceCell = document.createElement('td');
        priceCell.textContent = `$${price.toFixed(2)}`;

        row.appendChild(nameCell);
        row.appendChild(quantityCell);
        row.appendChild(priceCell);
        tableBody.appendChild(row);
    }

    function updateTotalPrice() {
        const tableBody = document.querySelector('#items-table tbody');
        let totalPrice = 0;

        tableBody.querySelectorAll('tr').forEach(row => {
            const priceCell = row.children[2];
            const price = parseFloat(priceCell.textContent.replace('$', ''));
            totalPrice += price;
        });

        document.getElementById('total-price').textContent = `$${totalPrice.toFixed(2)}`;
    }
});
